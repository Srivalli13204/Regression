#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing
import matplotlib.pyplot as plt
import pandas as pd
import pylab as pl
import numpy as np
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


#dataset
df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX.csv")
df.head()


# In[3]:


#some of the features
df1 = df[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_CITY','FUELCONSUMPTION_HWY','FUELCONSUMPTION_COMB','CO2EMISSIONS']]
df1.head(9)


# In[4]:


#plotting
plt.scatter(df1.ENGINESIZE, df1.CO2EMISSIONS,  color='blue')
plt.xlabel("ENGINESIZE")
plt.ylabel("CO2EMISSION")
plt.show()


# In[5]:


#splitting
split = np.random.rand(len(df)) < 0.8
train = df1[split]
test = df1[~split]


# In[6]:


#training
plt.scatter(train.ENGINESIZE, train.CO2EMISSIONS,  color='blue')
plt.xlabel("ENGINESIZE")
plt.ylabel("CO2EMISSION")
plt.show()


# In[7]:


#ENGINESIZE, CYLINDERS, FUELCONSUMPTION_COMB & CO2EMISSIONS


# In[8]:


#modelling
from sklearn import linear_model
train_x = np.asanyarray(train[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_COMB']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
reg = linear_model.LinearRegression()
fit = reg.fit (train_x, train_y)
print ('Coefficients: ', fit.coef_)
print (" Intercept : ", fit.intercept_)


# In[9]:


#calculations
test_x = np.asanyarray(test[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_COMB']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
predict = fit.predict(test_x)
print("Mean Squared Error (MSE) : %.2f" % np.mean((predict - test_y) ** 2))
print('Variance score: %.2f' % fit.score(test_x, test_y))


# In[10]:


#ENGINESIZE, CYLINDERS, FUELCONSUMPTION_CITY, FUELCONSUMPTION_HWY & CO2EMISSIONS


# In[11]:


from sklearn import linear_model
train_x = np.asanyarray(train[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_CITY', 'FUELCONSUMPTION_HWY']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
reg = linear_model.LinearRegression()
fit = reg.fit (train_x, train_y)
print ('Coefficients: ', fit.coef_)
print (" Intercept : ", fit.intercept_)


# In[12]:


test_x = np.asanyarray(test[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_CITY', 'FUELCONSUMPTION_HWY']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
predict = fit.predict(test_x)
print("Mean Squared Error (MSE) : %.2f" % np.mean((predict - test_y) ** 2))
print('Variance score: %.2f' % fit.score(test_x, test_y))

