#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing
import matplotlib.pyplot as plt
import pandas as pd
import pylab as pl
import numpy as np
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


#dataset
df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX.csv")
df.head()


# In[3]:


#summarize
df.describe()


# In[4]:


#some of the features
df1 = df[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_COMB','CO2EMISSIONS']]
df1.head(9)


# In[5]:


#plotting
plot = df1[['CYLINDERS','ENGINESIZE','CO2EMISSIONS','FUELCONSUMPTION_COMB']]
plot.hist()
plt.show()


# In[6]:


#fuelconsumption against emission
plt.scatter(df1.FUELCONSUMPTION_COMB, df1.CO2EMISSIONS,  color='maroon')
plt.xlabel("FUELCONSUMPTION_COMB")
plt.ylabel("CO2EMISSIONS")
plt.show()


# In[7]:


#cylinders against emission
plt.scatter(df1.CYLINDERS, df1.CO2EMISSIONS,  color='darkblue')
plt.xlabel("CYLINDERS")
plt.ylabel("CO2EMISSIon")
plt.show()


# In[8]:


#enginesize against emission
plt.scatter(df1.ENGINESIZE, df1.CO2EMISSIONS,  color='darkgreen')
plt.xlabel("ENGINESIZE")
plt.ylabel("CO2EMISSION")
plt.show()


# In[9]:


#splitting
split = np.random.rand(len(df)) < 0.8
train = df1[split]
test = df1[~split]


# In[10]:


#ENGINESIZE & EMISSION


# In[11]:


#training
plt.scatter(train.ENGINESIZE, train.CO2EMISSIONS,  color='purple')
plt.xlabel("ENGINESIZE")
plt.ylabel("CO2EMISSION")
plt.show()


# In[12]:


#modelling
from sklearn import linear_model
train_x = np.asanyarray(train[['ENGINESIZE']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
reg = linear_model.LinearRegression()
fit = reg.fit(train_x, train_y)
print ('Coefficients : ', fit.coef_)
print ('Intercept : ',fit.intercept_)


# In[13]:


#plotting
plt.scatter(train.ENGINESIZE, train.CO2EMISSIONS,  color='gold')
plt.plot(train_x, fit.coef_[0][0]*train_x + fit.intercept_[0], '-r')
plt.xlabel("ENGINESIZE")
plt.ylabel("CO2EMISSION")


# In[14]:


#calculations
from sklearn.metrics import r2_score
test_x = np.asanyarray(test[['ENGINESIZE']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
predict = fit.predict(test_x)
print("Mean Absolute Error (MAE) : %.2f" % np.mean(np.absolute(predict - test_y)))
print("Residual Sum of Squares (MSE) : %.2f" % np.mean((predict - test_y) ** 2))
print("R2 Score : %.2f" % r2_score(test_y , predict) )


# In[15]:


#FUELCONSUMPTION_COMB & EMISSION


# In[16]:


#training
plt.scatter(train.FUELCONSUMPTION_COMB, train.CO2EMISSIONS,  color='purple')
plt.xlabel("FUELCONSUMPTION_COMB")
plt.ylabel("CO2EMISSION")
plt.show()


# In[17]:


#modelling
from sklearn import linear_model
train_x = np.asanyarray(train[['FUELCONSUMPTION_COMB']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
reg = linear_model.LinearRegression()
fit = reg.fit(train_x, train_y)
print ('Coefficients : ', fit.coef_)
print ('Intercept : ',fit.intercept_)


# In[18]:


#plotting
plt.scatter(train.FUELCONSUMPTION_COMB, train.CO2EMISSIONS,  color='gold')
plt.plot(train_x, fit.coef_[0][0]*train_x + fit.intercept_[0], '-r')
plt.xlabel("FUELCONSUMPTION_COMB")
plt.ylabel("CO2EMISSION")


# In[19]:


#calculations
from sklearn.metrics import r2_score
test_x = np.asanyarray(test[['FUELCONSUMPTION_COMB']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
predict = reg.predict(test_x)
print("Mean Absolute Error (MAE) : %.2f" % np.mean(np.absolute(predict - test_y)))
print("Residual Sum of Squares (MSE) : %.2f" % np.mean((predict - test_y) ** 2))
print("R2 Score : %.2f" % r2_score(test_y , predict) )


# In[20]:


#CYLINDERS & EMISSION


# In[21]:


#training
plt.scatter(train.CYLINDERS, train.CO2EMISSIONS, color='purple')
plt.xlabel('CYLINDERS')
plt.ylabel('CO2EMISSION')
plt.show()


# In[22]:


#modelling
from sklearn import linear_model
train_x = np.asanyarray(train[['CYLINDERS']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
reg = linear_model.LinearRegression()
fit = reg.fit(train_x, train_y)
print("Coefficients : ",fit.coef_)
print("Intercept : ",fit.intercept_)


# In[23]:


#plotting
plt.scatter(train.CYLINDERS, train.CO2EMISSIONS, color='gold')
plt.plot(train_x, fit.coef_[0][0] * train_x + fit.intercept_, '-r')
plt.xlabel('CYLINDERS')
plt.ylabel('CO2EMISSION')


# In[24]:


#calculations
from sklearn.metrics import r2_score
test_x = np.asanyarray(test[['CYLINDERS']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
predict = fit.predict(test_x)
print("Mean Absolute Error (MAE) : %.2f" % np.mean(np.absolute(predict - test_y)))
print("Residual Sum of Squares (MSE) : %.2f" % np.mean(predict - test_y) ** 2)
print("R2 Score : %.2f" % r2_score(test_y, predict))

