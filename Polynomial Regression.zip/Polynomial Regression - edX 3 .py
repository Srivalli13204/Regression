#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing
import matplotlib.pyplot as plt
import pandas as pd
import pylab as pl
import numpy as np
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


#dataset
df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX.csv")
df.head()


# In[3]:


#summarize
df.describe()


# In[4]:


#some of the features
df1 = df[['ENGINESIZE','CYLINDERS','FUELCONSUMPTION_COMB','CO2EMISSIONS']]
df1.head(9)


# In[5]:


#plotting
plt.scatter(df1.ENGINESIZE, df1.CO2EMISSIONS,  color='blue')
plt.xlabel("Engine size")
plt.ylabel("Emission")
plt.show()


# In[6]:


#splitting
split = np.random.rand(len(df)) < 0.8
train = df1[split]
test = df1[~split]


# In[7]:


#degree2


# In[8]:


#training & testing
from sklearn.preprocessing import PolynomialFeatures
from sklearn import linear_model
train_x = np.asanyarray(train[['ENGINESIZE']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
test_x = np.asanyarray(test[['ENGINESIZE']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
poly = PolynomialFeatures(degree=2)
transform = poly.fit_transform(train_x)
print(transform)


# In[9]:


#modelling
reg = linear_model.LinearRegression()
fit = reg.fit(transform, train_y)


# In[10]:


print ('Coefficients: ', reg.coef_)


# In[11]:


print ('Intercept: ',reg.intercept_)


# In[12]:


#plotting
plt.scatter(train.ENGINESIZE, train.CO2EMISSIONS,  color='purple')
x = np.arange(0.0, 10.0, 0.1)
y = reg.intercept_[0] + reg.coef_[0][1] * x + reg.coef_[0][2] * np.power(x, 2)
plt.plot(x, y, '-r' )
plt.xlabel("Engine size")
plt.ylabel("Emission")


# In[13]:


#calculations
from sklearn.metrics import r2_score
trans = poly.transform(test_x)
predict = reg.predict(trans)


# In[14]:


print("Mean Absolute Error (MAE) : %.2f" % np.mean(np.absolute(predict - test_y)))


# In[15]:


print("Residual Sum of Squares (MSE) : %.2f" % np.mean((predict - test_y) ** 2))


# In[16]:


print("R2 Score : %.2f" % r2_score(test_y, predict) )


# In[17]:


#degree3


# In[18]:


#train & test
from sklearn.preprocessing import PolynomialFeatures
from sklearn import linear_model
train_x = np.asanyarray(train[['ENGINESIZE']])
train_y = np.asanyarray(train[['CO2EMISSIONS']])
test_x = np.asanyarray(test[['ENGINESIZE']])
test_y = np.asanyarray(test[['CO2EMISSIONS']])
poly = PolynomialFeatures(degree = 3)
transform = poly.fit_transform(train_x)
print(transform)


# In[19]:


#modelling
reg = linear_model.LinearRegression()
fit = reg.fit(transform, train_y)


# In[20]:


print("Coefficients : ",reg.coef_)


# In[21]:


print("Intercept : ",reg.intercept_)


# In[22]:


#plotting
plt.scatter(train.ENGINESIZE, train.CO2EMISSIONS, color='gold')
x = np.arange(0.0, 10.0, 1.0)
y = reg.intercept_[0] + reg.coef_[0][1] * x + reg.coef_[0][2] * np.power(x, 2)
plt.plot(x, y, '-r')
plt.xlabel("ENGINESIZE")
plt.ylabel("CO2EMISSIONS")


# In[23]:


#calculations
from sklearn.metrics import r2_score
trans = poly.transform(test_x)
predict = reg.predict(trans)


# In[24]:


print("Mean Absolute Error (MAE) : %.2f" % np.mean(np.absolute(predict - test_y)))


# In[25]:


print("Residual Sum of Squares (MSE) : %.2f" %np.mean((predict - test_y)) ** 2)


# In[26]:


print("R2 Score : %.2f" % r2_score(test_y, predict))

